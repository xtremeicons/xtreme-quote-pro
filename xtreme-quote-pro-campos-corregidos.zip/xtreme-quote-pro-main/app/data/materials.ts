export interface Material {
  id: number;
  category: string;
  name: string;
  unit: "ft²";
  cost: number;
  waste: number;
  recommendedMarkup: number;
  premiumMarkup: number;
}

export const materials: Material[] = [
  { id: 1, category: "banner", name: "13 oz Matte", unit: "ft²", cost: 0.85, waste: 10, recommendedMarkup: 150, premiumMarkup: 200 },
  { id: 2, category: "banner", name: "13 oz Gloss", unit: "ft²", cost: 0.95, waste: 10, recommendedMarkup: 150, premiumMarkup: 200 },
  { id: 3, category: "banner", name: "18 oz Blockout", unit: "ft²", cost: 1.35, waste: 12, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 4, category: "banner", name: "Mesh Banner", unit: "ft²", cost: 1.15, waste: 10, recommendedMarkup: 150, premiumMarkup: 200 },
  { id: 5, category: "coroplast", name: "4 mm White", unit: "ft²", cost: 1.8, waste: 8, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 6, category: "coroplast", name: "10 mm White", unit: "ft²", cost: 3.25, waste: 8, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 7, category: "vinyl", name: "Gloss Vinyl", unit: "ft²", cost: 2.25, waste: 12, recommendedMarkup: 150, premiumMarkup: 200 },
  { id: 8, category: "vinyl", name: "Matte Vinyl", unit: "ft²", cost: 2.45, waste: 12, recommendedMarkup: 150, premiumMarkup: 200 },
  { id: 9, category: "vinyl", name: "High Tack Vinyl", unit: "ft²", cost: 2.85, waste: 15, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 10, category: "window-perf", name: "50/50 Window Perf", unit: "ft²", cost: 3.25, waste: 15, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 11, category: "window-perf", name: "70/30 Window Perf", unit: "ft²", cost: 3.75, waste: 15, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 12, category: "magnets", name: "30 mil Magnet", unit: "ft²", cost: 4.5, waste: 10, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 13, category: "magnets", name: "20 mil Magnet", unit: "ft²", cost: 3.85, waste: 10, recommendedMarkup: 175, premiumMarkup: 225 },
  { id: 14, category: "business-cards", name: "14 pt Gloss", unit: "ft²", cost: 0, waste: 0, recommendedMarkup: 150, premiumMarkup: 200 },
  { id: 15, category: "business-cards", name: "16 pt Matte", unit: "ft²", cost: 0, waste: 0, recommendedMarkup: 150, premiumMarkup: 200 },
  { id: 16, category: "business-cards", name: "18 pt Premium", unit: "ft²", cost: 0, waste: 0, recommendedMarkup: 175, premiumMarkup: 225 },
];
