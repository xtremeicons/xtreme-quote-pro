export type MeasurementUnit = "pies" | "pulgadas";

export interface QuoteCalculationInput {
  width: number;
  height: number;
  quantity: number;
  unit: MeasurementUnit;
  costPerSquareFoot: number;
  wastePercent: number;
  markupPercent: number;
  design: number;
  installation: number;
  shipping: number;
  taxPercent: number;
}

export interface QuoteCalculationResult {
  areaPerPiece: number;
  baseArea: number;
  wasteArea: number;
  billableArea: number;
  baseMaterialCost: number;
  wasteCost: number;
  materialCost: number;
  profit: number;
  productPrice: number;
  subtotal: number;
  taxes: number;
  total: number;
}
