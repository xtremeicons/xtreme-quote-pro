import type { QuoteCalculationInput, QuoteCalculationResult } from "../types/quote";

export function calculateQuote(input: QuoteCalculationInput): QuoteCalculationResult {
  const widthInFeet = input.unit === "pulgadas" ? input.width / 12 : input.width;
  const heightInFeet = input.unit === "pulgadas" ? input.height / 12 : input.height;

  const areaPerPiece = Math.max(0, widthInFeet * heightInFeet);
  const baseArea = areaPerPiece * Math.max(1, input.quantity);
  const wasteArea = baseArea * (Math.max(0, input.wastePercent) / 100);
  const billableArea = baseArea + wasteArea;

  const baseMaterialCost = baseArea * Math.max(0, input.costPerSquareFoot);
  const wasteCost = wasteArea * Math.max(0, input.costPerSquareFoot);
  const materialCost = baseMaterialCost + wasteCost;

  const profit = materialCost * (Math.max(0, input.markupPercent) / 100);
  const productPrice = materialCost + profit;
  const subtotal = productPrice + input.design + input.installation + input.shipping;
  const taxes = subtotal * (Math.max(0, input.taxPercent) / 100);
  const total = subtotal + taxes;

  return {
    areaPerPiece,
    baseArea,
    wasteArea,
    billableArea,
    baseMaterialCost,
    wasteCost,
    materialCost,
    profit,
    productPrice,
    subtotal,
    taxes,
    total,
  };
}
