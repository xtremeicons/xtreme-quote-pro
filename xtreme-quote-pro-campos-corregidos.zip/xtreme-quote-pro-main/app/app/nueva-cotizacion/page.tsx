"use client";

import { useMemo, useState, type CSSProperties } from "react";

type NumericFieldValue = number | "";

const toNumber = (value: NumericFieldValue, fallback = 0) =>
  value === "" || Number.isNaN(Number(value)) ? fallback : Number(value);
import { materials } from "../../data/materials";
import { calculateQuote } from "../../services/quoteService";

const materialesPorCategoria = materials.reduce<Record<string, string[]>>(
  (acumulado, material) => {
    acumulado[material.category] ??= [];
    acumulado[material.category].push(material.name);
    return acumulado;
  },
  {}
);

const inputStyle: CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  padding: "12px",
  marginBottom: "12px",
  background: "#1f2937",
  color: "#ffffff",
  border: "1px solid #374151",
  borderRadius: "8px",
  outline: "none",
  fontSize: "16px",
};

const labelStyle: CSSProperties = {
  display: "block",
  marginBottom: "6px",
  color: "#d1d5db",
  fontSize: "14px",
  fontWeight: 600,
};

const sectionStyle: CSSProperties = {
  background: "#181818",
  padding: "22px",
  borderRadius: "14px",
  marginTop: "20px",
  maxWidth: "760px",
  border: "1px solid #292929",
};

export default function NuevaCotizacion() {
  const [nombreCliente, setNombreCliente] = useState("");
  const [empresa, setEmpresa] = useState("");
  const [telefono, setTelefono] = useState("");
  const [correo, setCorreo] = useState("");

  const [categoria, setCategoria] = useState("");
  const [material, setMaterial] = useState("");
  const [unidad, setUnidad] = useState("pies");

  const [ancho, setAncho] = useState<NumericFieldValue>(0);
  const [alto, setAlto] = useState<NumericFieldValue>(0);
  const [cantidad, setCantidad] = useState<NumericFieldValue>(1);
  const [notas, setNotas] = useState("");

  const [margen, setMargen] = useState<NumericFieldValue>(150);
  const [desperdicio, setDesperdicio] = useState<NumericFieldValue>(0);
  const [diseno, setDiseno] = useState<NumericFieldValue>(0);
  const [instalacion, setInstalacion] = useState<NumericFieldValue>(0);
  const [envio, setEnvio] = useState<NumericFieldValue>(0);
  const [impuestoPorcentaje, setImpuestoPorcentaje] = useState<NumericFieldValue>(0);

  const [calculado, setCalculado] = useState(false);

  const materialSeleccionado = materials.find((item) => item.name === material);
  const precioMaterial = materialSeleccionado?.cost ?? 0;

  const resultado = useMemo(
    () =>
      calculateQuote({
        width: toNumber(ancho),
        height: toNumber(alto),
        quantity: Math.max(1, toNumber(cantidad, 1)),
        unit: unidad === "pulgadas" ? "pulgadas" : "pies",
        costPerSquareFoot: precioMaterial,
        wastePercent: toNumber(desperdicio),
        markupPercent: toNumber(margen),
        design: toNumber(diseno),
        installation: toNumber(instalacion),
        shipping: toNumber(envio),
        taxPercent: toNumber(impuestoPorcentaje),
      }),
    [
      ancho,
      alto,
      cantidad,
      unidad,
      precioMaterial,
      desperdicio,
      margen,
      diseno,
      instalacion,
      envio,
      impuestoPorcentaje,
    ]
  );

  const {
    areaPerPiece,
    baseArea: areaTotal,
    wasteArea: areaDesperdicio,
    billableArea: areaConDesperdicio,
    baseMaterialCost: costoMaterialSinDesperdicio,
    wasteCost: costoDesperdicio,
    materialCost: costoMaterial,
    profit: ganancia,
    productPrice: precioProducto,
    subtotal,
    taxes: impuestos,
    total,
  } = resultado;

  const cambiarCategoria = (nuevaCategoria: string) => {
    setCategoria(nuevaCategoria);
    setMaterial("");
    setDesperdicio(0);
    setCalculado(false);
  };

  const calcularCotizacion = () => {
    setCalculado(true);
  };

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#0d0d0d",
        color: "white",
        padding: "40px 20px",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <div style={{ maxWidth: "760px", margin: "0 auto" }}>
        <h1 style={{ marginBottom: "8px" }}>🧾 Nueva Cotización</h1>

        <p style={{ color: "#9ca3af", marginTop: 0 }}>
          Xtreme Quote Pro
        </p>

        <section style={sectionStyle}>
          <h2>👤 Información del Cliente</h2>

          <label style={labelStyle}>Nombre del cliente</label>
          <input
            type="text"
            value={nombreCliente}
            onChange={(e) => setNombreCliente(e.target.value)}
            style={inputStyle}
          />

          <label style={labelStyle}>Empresa</label>
          <input
            type="text"
            value={empresa}
            onChange={(e) => setEmpresa(e.target.value)}
            style={inputStyle}
          />

          <label style={labelStyle}>Teléfono</label>
          <input
            type="tel"
            value={telefono}
            onChange={(e) => setTelefono(e.target.value)}
            style={inputStyle}
          />

          <label style={labelStyle}>Correo electrónico</label>
          <input
            type="email"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
            style={inputStyle}
          />
        </section>

        <section style={sectionStyle}>
          <h2>📦 Información del Producto</h2>

          <label style={labelStyle}>Categoría</label>
          <select
            value={categoria}
            onChange={(e) => cambiarCategoria(e.target.value)}
            style={inputStyle}
          >
            <option value="">Selecciona una categoría</option>
            <option value="banner">Banner</option>
            <option value="coroplast">Coroplast</option>
            <option value="vinyl">Vinilo adhesivo</option>
            <option value="window-perf">Window Perf</option>
            <option value="magnets">Imanes</option>
            <option value="business-cards">
              Tarjetas de presentación
            </option>
          </select>

          <label style={labelStyle}>Material</label>
          <select
            value={material}
            onChange={(e) => {
              const nuevoMaterial = materials.find(
                (item) => item.name === e.target.value
              );
              setMaterial(e.target.value);
              setDesperdicio(nuevoMaterial?.waste ?? 0);
              setMargen(nuevoMaterial?.recommendedMarkup ?? 150);
              setCalculado(false);
            }}
            disabled={!categoria}
            style={{
              ...inputStyle,
              opacity: categoria ? 1 : 0.55,
              cursor: categoria ? "pointer" : "not-allowed",
            }}
          >
            <option value="">
              {categoria
                ? "Selecciona un material"
                : "Primero selecciona una categoría"}
            </option>

            {categoria &&
              materialesPorCategoria[categoria]?.map((nombreMaterial) => (
                <option key={nombreMaterial} value={nombreMaterial}>
                  {nombreMaterial}
                </option>
              ))}
          </select>

          <label style={labelStyle}>Unidad de medida</label>
          <select
            value={unidad}
            onChange={(e) => {
              setUnidad(e.target.value);
              setCalculado(false);
            }}
            style={inputStyle}
          >
            <option value="pies">Pies</option>
            <option value="pulgadas">Pulgadas</option>
          </select>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "12px",
            }}
          >
            <div>
              <label style={labelStyle}>Ancho</label>
              <input
                type="number"
                onFocus={(e) => e.currentTarget.select()}
                min="0"
                step="0.01"
                value={ancho}
                onChange={(e) => {
                  setAncho(e.target.value === "" ? "" : Number(e.target.value));
                  setCalculado(false);
                }}
                style={inputStyle}
              />
            </div>

            <div>
              <label style={labelStyle}>Alto</label>
              <input
                type="number"
                onFocus={(e) => e.currentTarget.select()}
                min="0"
                step="0.01"
                value={alto}
                onChange={(e) => {
                  setAlto(e.target.value === "" ? "" : Number(e.target.value));
                  setCalculado(false);
                }}
                style={inputStyle}
              />
            </div>
          </div>

          <label style={labelStyle}>Cantidad</label>
          <input
            type="number"
            onFocus={(e) => e.currentTarget.select()}
            min="1"
            value={cantidad}
            onChange={(e) => {
              setCantidad(e.target.value === "" ? "" : Number(e.target.value));
              setCalculado(false);
            }}
            onBlur={() => {
              if (toNumber(cantidad) < 1) setCantidad(1);
            }}
            style={inputStyle}
          />

          <div
            style={{
              background: "#101010",
              padding: "16px",
              borderRadius: "10px",
              marginBottom: "12px",
              border: "1px solid #292929",
            }}
          >
            <div>Área por pieza: {areaPerPiece.toFixed(2)} ft²</div>
            <div style={{ marginTop: "8px" }}>
              Área total sin desperdicio: {areaTotal.toFixed(2)} ft²
            </div>
            <div style={{ marginTop: "8px", color: "#fbbf24" }}>
              Desperdicio: {areaDesperdicio.toFixed(2)} ft² ({toNumber(desperdicio).toFixed(2)}%)
            </div>
            <div style={{ marginTop: "8px", fontWeight: 700 }}>
              Área facturable: {areaConDesperdicio.toFixed(2)} ft²
            </div>
          </div>

          <label style={labelStyle}>Descripción o notas</label>
          <textarea
            value={notas}
            onChange={(e) => setNotas(e.target.value)}
            rows={4}
            style={{
              ...inputStyle,
              resize: "vertical",
            }}
          />
        </section>

        <section style={sectionStyle}>
          <h2>💰 Precio y servicios</h2>

          <label style={labelStyle}>Desperdicio del material (%)</label>
          <input
            type="number"
            onFocus={(e) => e.currentTarget.select()}
            min="0"
            max="100"
            step="0.01"
            value={desperdicio}
            onChange={(e) => {
              setDesperdicio(e.target.value === "" ? "" : Number(e.target.value));
              setCalculado(false);
            }}
            style={inputStyle}
          />
          <p style={{ color: "#9ca3af", marginTop: "-6px", fontSize: "13px" }}>
            Se carga automáticamente según el material, pero puedes modificarlo.
          </p>

          <label style={labelStyle}>Recargo sobre costo (%)</label>
          <input
            type="number"
            onFocus={(e) => e.currentTarget.select()}
            min="0"
            value={margen}
            onChange={(e) => {
              setMargen(e.target.value === "" ? "" : Number(e.target.value));
              setCalculado(false);
            }}
            style={inputStyle}
          />

          <label style={labelStyle}>Diseño</label>
          <input
            type="number"
            onFocus={(e) => e.currentTarget.select()}
            min="0"
            step="0.01"
            value={diseno}
            onChange={(e) => {
              setDiseno(e.target.value === "" ? "" : Number(e.target.value));
              setCalculado(false);
            }}
            style={inputStyle}
          />

          <label style={labelStyle}>Instalación</label>
          <input
            type="number"
            onFocus={(e) => e.currentTarget.select()}
            min="0"
            step="0.01"
            value={instalacion}
            onChange={(e) => {
              setInstalacion(e.target.value === "" ? "" : Number(e.target.value));
              setCalculado(false);
            }}
            style={inputStyle}
          />

          <label style={labelStyle}>Envío</label>
          <input
            type="number"
            onFocus={(e) => e.currentTarget.select()}
            min="0"
            step="0.01"
            value={envio}
            onChange={(e) => {
              setEnvio(e.target.value === "" ? "" : Number(e.target.value));
              setCalculado(false);
            }}
            style={inputStyle}
          />

          <label style={labelStyle}>Impuestos (%)</label>
          <input
            type="number"
            onFocus={(e) => e.currentTarget.select()}
            min="0"
            step="0.01"
            value={impuestoPorcentaje}
            onChange={(e) => {
              setImpuestoPorcentaje(e.target.value === "" ? "" : Number(e.target.value));
              setCalculado(false);
            }}
            style={inputStyle}
          />

          <button
            type="button"
            onClick={calcularCotizacion}
            style={{
              width: "100%",
              padding: "15px",
              marginTop: "8px",
              background: "#d00000",
              color: "white",
              border: "none",
              borderRadius: "9px",
              cursor: "pointer",
              fontSize: "18px",
              fontWeight: "bold",
            }}
          >
            🧮 Calcular Cotización
          </button>
        </section>

        {calculado && (
          <section style={sectionStyle}>
            <h2>📄 Resultado</h2>

            <div
              style={{
                display: "grid",
                gap: "10px",
                background: "#101010",
                padding: "18px",
                borderRadius: "10px",
                border: "1px solid #292929",
              }}
            >
              <div>
                Precio por ft²: ${precioMaterial.toFixed(2)}
              </div>

              <div>
                Área sin desperdicio: {areaTotal.toFixed(2)} ft²
              </div>

              <div style={{ color: "#fbbf24" }}>
                Desperdicio agregado: {areaDesperdicio.toFixed(2)} ft² ({toNumber(desperdicio).toFixed(2)}%)
              </div>

              <div>
                Área facturable: {areaConDesperdicio.toFixed(2)} ft²
              </div>

              <div>
                Costo sin desperdicio: ${costoMaterialSinDesperdicio.toFixed(2)}
              </div>

              <div style={{ color: "#fbbf24" }}>
                Costo del desperdicio: ${costoDesperdicio.toFixed(2)}
              </div>

              <div>
                Costo total del material: ${costoMaterial.toFixed(2)}
              </div>

              <div>Ganancia: ${ganancia.toFixed(2)}</div>

              <div>
                Precio del producto: ${precioProducto.toFixed(2)}
              </div>

              <div>Diseño: ${toNumber(diseno).toFixed(2)}</div>

              <div>Instalación: ${toNumber(instalacion).toFixed(2)}</div>

              <div>Envío: ${toNumber(envio).toFixed(2)}</div>

              <div>Subtotal: ${subtotal.toFixed(2)}</div>

              <div>Impuestos: ${impuestos.toFixed(2)}</div>

              <div
                style={{
                  marginTop: "8px",
                  paddingTop: "14px",
                  borderTop: "1px solid #333",
                  fontSize: "26px",
                  fontWeight: "bold",
                  color: "#ff3030",
                }}
              >
                Total: ${total.toFixed(2)}
              </div>
            </div>
          </section>
        )}
      </div>
    </main>
  );
}